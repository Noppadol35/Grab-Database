<header class="site-header">
  <h2>Colorfull 09AF</h2>
  <div>
    <a href="./">หน้าแรก</a>
    <a href="new-color.php">เพิ่มสีใหม่</a>
  </div>
</header>

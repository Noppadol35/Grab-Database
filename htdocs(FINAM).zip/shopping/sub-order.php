<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'grab';

$conn = mysqli_connect($servername, $username, $password, $dbname);


$order_ID = "";
$order_product = $_POST['order_product'];
$order_price = $_POST['order_price'];
$order_status = $_POST['order_status'];
$order_date = $_POST['order_date'];
$cus_email = $_POST['cus_email'];
$pay_type = $_POST['pay_type'];
$res_email = $_POST['res_email'];


$sql = "INSERT INTO food_order (order_ID, order_product, order_price, order_status, order_date, cus_email, res_email, pay_type)
VALUES ('', '$order_product', '$order_price', '$order_status', '$order_date', '$cus_email', '$res_email', '$pay_type')";






if(mysqli_query($conn, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}








$sql = "DELETE FROM cart WHERE cus_email = '$cus_email'";
mysqli_query($conn, $sql);

mysqli_close($conn);


?>
<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'grab';

$conn = mysqli_connect($servername, $username, $password, $dbname);


$food_ID = $_POST['food_ID'];
$name = $_POST['name'];
$quantity = $_POST['quantity'];

echo "The food ID is: " . $food_ID;
echo "The name is: " . $name;


$sql = "SELECT * FROM food WHERE food_ID = '$food_ID'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");

while ($objResult = mysqli_fetch_array($objQuery)) {
    
    $food_picture = $objResult["food_picture"];
    $food_ID = $objResult["food_ID"];
    $food_name = $objResult["food_name"];
    $food_detail = $objResult["food_detail"];
    $food_price = $objResult["food_price"];
    $res_email = $objResult["res_email"];

    


    echo "The food ID is: " . $food_ID;
    echo "The food name is: " . $food_name;
    echo "The food detail is: " . $food_detail;
    echo "The food price is: " . $food_price;
    echo "The food picture is: " . $food_picture;
    echo "The res email is: " . $res_email;

}

$QUT = $quantity;

$subtotal = $QUT * $food_price;

$sql = "INSERT INTO cart (cus_email, food_picture, food_ID, food_name, food_detail, food_amount, food_price, food_total, res_email) 
VALUES ('$name', '$food_picture', '$food_ID', '$food_name', '$food_detail', '$QUT', '$food_price', '$subtotal', '$res_email')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
